# Details

Date : 2025-08-23 11:37:38

Directory c:\\IQOL\\acn-native

Total : 304 files,  165326 codes, 1756 comments, 3543 blanks, all 170625 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [.idea/acn-native.iml](/.idea/acn-native.iml) | XML | 9 | 0 | 0 | 9 |
| [.idea/caches/deviceStreaming.xml](/.idea/caches/deviceStreaming.xml) | XML | 703 | 0 | 0 | 703 |
| [.idea/misc.xml](/.idea/misc.xml) | XML | 5 | 0 | 0 | 5 |
| [.idea/modules.xml](/.idea/modules.xml) | XML | 8 | 0 | 0 | 8 |
| [.idea/vcs.xml](/.idea/vcs.xml) | XML | 6 | 0 | 0 | 6 |
| [README.md](/README.md) | Markdown | 32 | 0 | 21 | 53 |
| [app.json](/app.json) | JSON | 77 | 0 | 1 | 78 |
| [app/(pages)/CheckoutScreen.tsx](/app/(pages)/CheckoutScreen.tsx) | TypeScript JSX | 470 | 14 | 58 | 542 |
| [app/(pages)/ComparePlans.tsx](/app/(pages)/ComparePlans.tsx) | TypeScript JSX | 412 | 40 | 24 | 476 |
| [app/(pages)/Credits.tsx](/app/(pages)/Credits.tsx) | TypeScript JSX | 398 | 18 | 41 | 457 |
| [app/(pages)/Drafts.tsx](/app/(pages)/Drafts.tsx) | TypeScript JSX | 229 | 1 | 17 | 247 |
| [app/(pages)/Legal.tsx](/app/(pages)/Legal.tsx) | TypeScript JSX | 359 | 49 | 31 | 439 |
| [app/(pages)/PaymentRecords.tsx](/app/(pages)/PaymentRecords.tsx) | TypeScript JSX | 289 | 24 | 23 | 336 |
| [app/(pages)/Profile.tsx](/app/(pages)/Profile.tsx) | TypeScript JSX | 256 | 3 | 14 | 273 |
| [app/(pages)/legalContent.ts](/app/(pages)/legalContent.ts) | TypeScript | 387 | 0 | 2 | 389 |
| [app/(tabs)/AddInventoryForm.tsx](/app/(tabs)/AddInventoryForm.tsx) | TypeScript JSX | 1,391 | 40 | 101 | 1,532 |
| [app/(tabs)/NotificationPage.tsx](/app/(tabs)/NotificationPage.tsx) | TypeScript JSX | 642 | 45 | 54 | 741 |
| [app/(tabs)/ReportIssue.tsx](/app/(tabs)/ReportIssue.tsx) | TypeScript JSX | 316 | 11 | 33 | 360 |
| [app/(tabs)/UserRequirementForm.tsx](/app/(tabs)/UserRequirementForm.tsx) | TypeScript JSX | 726 | 42 | 58 | 826 |
| [app/(tabs)/billings.tsx](/app/(tabs)/billings.tsx) | TypeScript JSX | 65 | 1 | 9 | 75 |
| [app/(tabs)/dashboardTab.tsx](/app/(tabs)/dashboardTab.tsx) | TypeScript JSX | 501 | 22 | 65 | 588 |
| [app/(tabs)/explore.tsx](/app/(tabs)/explore.tsx) | TypeScript JSX | 126 | 0 | 4 | 130 |
| [app/(tabs)/help.tsx](/app/(tabs)/help.tsx) | TypeScript JSX | 283 | 16 | 35 | 334 |
| [app/(tabs)/index.tsx](/app/(tabs)/index.tsx) | TypeScript JSX | 125 | 30 | 22 | 177 |
| [app/(tabs)/properties.tsx](/app/(tabs)/properties.tsx) | TypeScript JSX | 473 | 10 | 37 | 520 |
| [app/(tabs)/requirements.tsx](/app/(tabs)/requirements.tsx) | TypeScript JSX | 370 | 9 | 35 | 414 |
| [app/+not-found.tsx](/app/+not-found.tsx) | TypeScript JSX | 30 | 0 | 4 | 34 |
| [app/VersionChecker.tsx](/app/VersionChecker.tsx) | TypeScript JSX | 218 | 5 | 26 | 249 |
| [app/\_layout.tsx](/app/_layout.tsx) | TypeScript JSX | 58 | 38 | 16 | 112 |
| [app/\_layoutApp.tsx](/app/_layoutApp.tsx) | TypeScript JSX | 599 | 13 | 50 | 662 |
| [app/components/Auth/BlacklistedPage.tsx](/app/components/Auth/BlacklistedPage.tsx) | TypeScript JSX | 131 | 0 | 10 | 141 |
| [app/components/Auth/LandingPage.tsx](/app/components/Auth/LandingPage.tsx) | TypeScript JSX | 312 | 2 | 17 | 331 |
| [app/components/Auth/OTPage.tsx](/app/components/Auth/OTPage.tsx) | TypeScript JSX | 389 | 5 | 28 | 422 |
| [app/components/Auth/Signin.tsx](/app/components/Auth/Signin.tsx) | TypeScript JSX | 395 | 46 | 36 | 477 |
| [app/components/Auth/VerificationPage.tsx](/app/components/Auth/VerificationPage.tsx) | TypeScript JSX | 105 | 0 | 6 | 111 |
| [app/components/Auth/\_layout.tsx](/app/components/Auth/_layout.tsx) | TypeScript JSX | 65 | 14 | 13 | 92 |
| [app/components/Billing/BillingContainer.tsx](/app/components/Billing/BillingContainer.tsx) | TypeScript JSX | 1,774 | 84 | 152 | 2,010 |
| [app/components/Billing/BusinessDetailsModal.tsx](/app/components/Billing/BusinessDetailsModal.tsx) | TypeScript JSX | 278 | 4 | 29 | 311 |
| [app/components/Button/ARPrimaryButton.tsx](/app/components/Button/ARPrimaryButton.tsx) | TypeScript JSX | 100 | 0 | 9 | 109 |
| [app/components/Button/ARSecondaryButton.tsx](/app/components/Button/ARSecondaryButton.tsx) | TypeScript JSX | 107 | 0 | 9 | 116 |
| [app/components/CustomCurrentRefinements.tsx](/app/components/CustomCurrentRefinements.tsx) | TypeScript JSX | 172 | 3 | 11 | 186 |
| [app/components/CustomPagination.tsx](/app/components/CustomPagination.tsx) | TypeScript JSX | 235 | 8 | 23 | 266 |
| [app/components/CustomSelectDropdown.tsx](/app/components/CustomSelectDropdown.tsx) | TypeScript JSX | 282 | 1 | 14 | 297 |
| [app/components/DropdownMoreFilters.tsx](/app/components/DropdownMoreFilters.tsx) | TypeScript JSX | 275 | 5 | 23 | 303 |
| [app/components/DropdownRefinementList.tsx](/app/components/DropdownRefinementList.tsx) | TypeScript JSX | 168 | 0 | 9 | 177 |
| [app/components/Enquiries/EnquiryCard.tsx](/app/components/Enquiries/EnquiryCard.tsx) | TypeScript JSX | 161 | 6 | 14 | 181 |
| [app/components/Enquiries/ReviewModal.tsx](/app/components/Enquiries/ReviewModal.tsx) | TypeScript JSX | 266 | 0 | 23 | 289 |
| [app/components/LandmarkDropdownFilters.tsx](/app/components/LandmarkDropdownFilters.tsx) | TypeScript JSX | 464 | 31 | 37 | 532 |
| [app/components/Listing/AssetTypeSelection.tsx](/app/components/Listing/AssetTypeSelection.tsx) | TypeScript JSX | 202 | 7 | 18 | 227 |
| [app/components/Listing/CheckBox.tsx](/app/components/Listing/CheckBox.tsx) | TypeScript JSX | 97 | 0 | 7 | 104 |
| [app/components/Listing/ComponentObjects/appartmentComponents.tsx](/app/components/Listing/ComponentObjects/appartmentComponents.tsx) | TypeScript JSX | 297 | 1 | 1 | 299 |
| [app/components/Listing/ComponentObjects/formComponents.tsx](/app/components/Listing/ComponentObjects/formComponents.tsx) | TypeScript JSX | 91 | 0 | 3 | 94 |
| [app/components/Listing/ComponentObjects/independentComponents.tsx](/app/components/Listing/ComponentObjects/independentComponents.tsx) | TypeScript JSX | 308 | 2 | 1 | 311 |
| [app/components/Listing/ComponentObjects/plotComponents.tsx](/app/components/Listing/ComponentObjects/plotComponents.tsx) | TypeScript JSX | 140 | 12 | 1 | 153 |
| [app/components/Listing/ComponentObjects/rowhouseComponents.tsx](/app/components/Listing/ComponentObjects/rowhouseComponents.tsx) | TypeScript JSX | 308 | 2 | 1 | 311 |
| [app/components/Listing/ComponentObjects/villaComponents.tsx](/app/components/Listing/ComponentObjects/villaComponents.tsx) | TypeScript JSX | 308 | 2 | 1 | 311 |
| [app/components/Listing/ComponentObjects/villamentComponents.tsx](/app/components/Listing/ComponentObjects/villamentComponents.tsx) | TypeScript JSX | 301 | 3 | 1 | 305 |
| [app/components/Listing/DraftCard.tsx](/app/components/Listing/DraftCard.tsx) | TypeScript JSX | 109 | 4 | 9 | 122 |
| [app/components/Listing/Dropdown.tsx](/app/components/Listing/Dropdown.tsx) | TypeScript JSX | 256 | 7 | 15 | 278 |
| [app/components/Listing/ExtraDetails.tsx](/app/components/Listing/ExtraDetails.tsx) | TypeScript JSX | 103 | 3 | 8 | 114 |
| [app/components/Listing/Khata.tsx](/app/components/Listing/Khata.tsx) | TypeScript JSX | 0 | 0 | 1 | 1 |
| [app/components/Listing/MonthYearPicker.tsx](/app/components/Listing/MonthYearPicker.tsx) | TypeScript JSX | 163 | 2 | 13 | 178 |
| [app/components/Listing/MuliSelectSliderButton.tsx](/app/components/Listing/MuliSelectSliderButton.tsx) | TypeScript JSX | 139 | 2 | 7 | 148 |
| [app/components/Listing/PlacesSearch.tsx](/app/components/Listing/PlacesSearch.tsx) | TypeScript JSX | 359 | 21 | 28 | 408 |
| [app/components/Listing/RadioButtonSelect.tsx](/app/components/Listing/RadioButtonSelect.tsx) | TypeScript JSX | 113 | 0 | 7 | 120 |
| [app/components/Listing/SliderButtonSelect.tsx](/app/components/Listing/SliderButtonSelect.tsx) | TypeScript JSX | 120 | 0 | 7 | 127 |
| [app/components/Listing/TextInput.tsx](/app/components/Listing/TextInput.tsx) | TypeScript JSX | 197 | 15 | 15 | 227 |
| [app/components/Listing/TotalAskPrice.tsx](/app/components/Listing/TotalAskPrice.tsx) | TypeScript JSX | 398 | 26 | 33 | 457 |
| [app/components/Listing/document/Document.tsx](/app/components/Listing/document/Document.tsx) | TypeScript JSX | 79 | 0 | 9 | 88 |
| [app/components/Listing/document/FilePreview.tsx](/app/components/Listing/document/FilePreview.tsx) | TypeScript JSX | 149 | 2 | 15 | 166 |
| [app/components/Listing/document/FileUpload.tsx](/app/components/Listing/document/FileUpload.tsx) | TypeScript JSX | 213 | 26 | 28 | 267 |
| [app/components/Loader.tsx](/app/components/Loader.tsx) | TypeScript JSX | 107 | 11 | 11 | 129 |
| [app/components/MonthFilterDropdown.tsx](/app/components/MonthFilterDropdown.tsx) | TypeScript JSX | 123 | 0 | 13 | 136 |
| [app/components/MoreFilters.tsx](/app/components/MoreFilters.tsx) | TypeScript JSX | 569 | 23 | 48 | 640 |
| [app/components/Notification/ArchivedNotifications.tsx](/app/components/Notification/ArchivedNotifications.tsx) | TypeScript JSX | 175 | 6 | 15 | 196 |
| [app/components/Notification/NotificationCard.tsx](/app/components/Notification/NotificationCard.tsx) | TypeScript JSX | 380 | 32 | 12 | 424 |
| [app/components/Notification/NotificationMoreOptions.tsx](/app/components/Notification/NotificationMoreOptions.tsx) | TypeScript JSX | 119 | 0 | 8 | 127 |
| [app/components/Notification/NotificationSettings.tsx](/app/components/Notification/NotificationSettings.tsx) | TypeScript JSX | 207 | 1 | 13 | 221 |
| [app/components/Notification/Notifications.tsx](/app/components/Notification/Notifications.tsx) | TypeScript JSX | 131 | 27 | 20 | 178 |
| [app/components/Notification/Readme.md](/app/components/Notification/Readme.md) | Markdown | 90 | 0 | 60 | 150 |
| [app/components/Notification/SwipeableArchivedNotificationCard.tsx](/app/components/Notification/SwipeableArchivedNotificationCard.tsx) | TypeScript JSX | 213 | 4 | 19 | 236 |
| [app/components/Notification/SwipeableNotificationCard.tsx](/app/components/Notification/SwipeableNotificationCard.tsx) | TypeScript JSX | 258 | 9 | 21 | 288 |
| [app/components/Notification/UndoArchiveModal.tsx](/app/components/Notification/UndoArchiveModal.tsx) | TypeScript JSX | 165 | 3 | 15 | 183 |
| [app/components/Notification/useNotification.ts](/app/components/Notification/useNotification.ts) | TypeScript | 399 | 22 | 53 | 474 |
| [app/components/Offline.tsx](/app/components/Offline.tsx) | TypeScript JSX | 80 | 0 | 6 | 86 |
| [app/components/Onboarding/components/BenefitItem.tsx](/app/components/Onboarding/components/BenefitItem.tsx) | TypeScript JSX | 20 | 0 | 4 | 24 |
| [app/components/Onboarding/components/CloseButton.tsx](/app/components/Onboarding/components/CloseButton.tsx) | TypeScript JSX | 13 | 0 | 3 | 16 |
| [app/components/Onboarding/components/OnboardingCard.tsx](/app/components/Onboarding/components/OnboardingCard.tsx) | TypeScript JSX | 13 | 0 | 3 | 16 |
| [app/components/Onboarding/components/OnboardingContext.tsx](/app/components/Onboarding/components/OnboardingContext.tsx) | TypeScript JSX | 131 | 1 | 16 | 148 |
| [app/components/Onboarding/components/OnboardingFlow.tsx](/app/components/Onboarding/components/OnboardingFlow.tsx) | TypeScript JSX | 141 | 0 | 14 | 155 |
| [app/components/Onboarding/components/OnboardingModal.tsx](/app/components/Onboarding/components/OnboardingModal.tsx) | TypeScript JSX | 101 | 5 | 9 | 115 |
| [app/components/Onboarding/components/PrimaryButton.tsx](/app/components/Onboarding/components/PrimaryButton.tsx) | TypeScript JSX | 24 | 0 | 4 | 28 |
| [app/components/Onboarding/index.ts](/app/components/Onboarding/index.ts) | TypeScript | 3 | 0 | 0 | 3 |
| [app/components/Onboarding/screens/BenefitsScreen.tsx](/app/components/Onboarding/screens/BenefitsScreen.tsx) | TypeScript JSX | 97 | 0 | 13 | 110 |
| [app/components/Onboarding/screens/SuccessScreen.tsx](/app/components/Onboarding/screens/SuccessScreen.tsx) | TypeScript JSX | 80 | 0 | 11 | 91 |
| [app/components/Onboarding/screens/TrialInfoScreen.tsx](/app/components/Onboarding/screens/TrialInfoScreen.tsx) | TypeScript JSX | 115 | 0 | 16 | 131 |
| [app/components/Onboarding/screens/WelcomeScreen.tsx](/app/components/Onboarding/screens/WelcomeScreen.tsx) | TypeScript JSX | 84 | 1 | 11 | 96 |
| [app/components/Payments/PaymentHeader.tsx](/app/components/Payments/PaymentHeader.tsx) | TypeScript JSX | 344 | 5 | 7 | 356 |
| [app/components/Payments/transaction.tsx](/app/components/Payments/transaction.tsx) | TypeScript JSX | 555 | 9 | 20 | 584 |
| [app/components/ProfilePage/CreditsCard.tsx](/app/components/ProfilePage/CreditsCard.tsx) | TypeScript JSX | 140 | 2 | 7 | 149 |
| [app/components/ProfilePage/GetPremiumCard.tsx](/app/components/ProfilePage/GetPremiumCard.tsx) | TypeScript JSX | 282 | 7 | 15 | 304 |
| [app/components/ProfilePage/ProfileCard.tsx](/app/components/ProfilePage/ProfileCard.tsx) | TypeScript JSX | 70 | 0 | 7 | 77 |
| [app/components/ProfilePage/UserDetailsCard.tsx](/app/components/ProfilePage/UserDetailsCard.tsx) | TypeScript JSX | 156 | 14 | 7 | 177 |
| [app/components/PropertyFilters.tsx](/app/components/PropertyFilters.tsx) | TypeScript JSX | 250 | 14 | 15 | 279 |
| [app/components/RangeMoreFilters.tsx](/app/components/RangeMoreFilters.tsx) | TypeScript JSX | 212 | 9 | 21 | 242 |
| [app/components/RecentEnquiries.tsx](/app/components/RecentEnquiries.tsx) | TypeScript JSX | 181 | 10 | 15 | 206 |
| [app/components/TrialStatusNotification.tsx](/app/components/TrialStatusNotification.tsx) | TypeScript JSX | 347 | 13 | 27 | 387 |
| [app/components/dashboard/Dashboard.tsx](/app/components/dashboard/Dashboard.tsx) | TypeScript JSX | 622 | 15 | 39 | 676 |
| [app/components/dashboard/DashboardDropdown.tsx](/app/components/dashboard/DashboardDropdown.tsx) | TypeScript JSX | 267 | 2 | 14 | 283 |
| [app/components/dashboard/EmptyTabContent.tsx](/app/components/dashboard/EmptyTabContent.tsx) | TypeScript JSX | 142 | 1 | 7 | 150 |
| [app/components/dashboard/PropertyCard.tsx](/app/components/dashboard/PropertyCard.tsx) | TypeScript JSX | 241 | 22 | 24 | 287 |
| [app/components/dashboard/PropertyTabCarousel.tsx](/app/components/dashboard/PropertyTabCarousel.tsx) | TypeScript JSX | 162 | 0 | 11 | 173 |
| [app/components/dashboard/RequirementCard.tsx](/app/components/dashboard/RequirementCard.tsx) | TypeScript JSX | 147 | 9 | 15 | 171 |
| [app/components/dashboard/TabCarousel.tsx](/app/components/dashboard/TabCarousel.tsx) | TypeScript JSX | 153 | 7 | 17 | 177 |
| [app/components/property/BudgetRangeSlider.tsx](/app/components/property/BudgetRangeSlider.tsx) | TypeScript JSX | 125 | 11 | 18 | 154 |
| [app/components/property/ImageCarousel.tsx](/app/components/property/ImageCarousel.tsx) | TypeScript JSX | 343 | 9 | 21 | 373 |
| [app/components/property/PropertyCard.tsx](/app/components/property/PropertyCard.tsx) | TypeScript JSX | 687 | 43 | 73 | 803 |
| [app/components/property/PropertyDetailsScreen.tsx](/app/components/property/PropertyDetailsScreen.tsx) | TypeScript JSX | 1,211 | 66 | 65 | 1,342 |
| [app/components/requirement/CheckboxFilter.tsx](/app/components/requirement/CheckboxFilter.tsx) | TypeScript JSX | 111 | 2 | 8 | 121 |
| [app/components/requirement/DetailsModal.tsx](/app/components/requirement/DetailsModal.tsx) | TypeScript JSX | 166 | 0 | 11 | 177 |
| [app/components/requirement/MoreFiltersRequirement.tsx](/app/components/requirement/MoreFiltersRequirement.tsx) | TypeScript JSX | 291 | 10 | 25 | 326 |
| [app/components/requirement/RequirementCard.tsx](/app/components/requirement/RequirementCard.tsx) | TypeScript JSX | 122 | 14 | 24 | 160 |
| [app/components/requirement/RequirementDetailsModal.tsx](/app/components/requirement/RequirementDetailsModal.tsx) | TypeScript JSX | 144 | 14 | 24 | 182 |
| [app/components/requirement/RequirementDetailsScreen.tsx](/app/components/requirement/RequirementDetailsScreen.tsx) | TypeScript JSX | 359 | 17 | 35 | 411 |
| [app/components/requirement/RequirementFilters.tsx](/app/components/requirement/RequirementFilters.tsx) | TypeScript JSX | 198 | 39 | 18 | 255 |
| [app/config/firebase.ts](/app/config/firebase.ts) | TypeScript | 16 | 3 | 4 | 23 |
| [app/constants/DocumentConstants.tsx](/app/constants/DocumentConstants.tsx) | TypeScript JSX | 10 | 0 | 2 | 12 |
| [app/constants/PropertyConstants.tsx](/app/constants/PropertyConstants.tsx) | TypeScript JSX | 30 | 0 | 2 | 32 |
| [app/helpers/areasData.js](/app/helpers/areasData.js) | JavaScript | 193 | 0 | 0 | 193 |
| [app/helpers/checkUpdates.tsx](/app/helpers/checkUpdates.tsx) | TypeScript JSX | 59 | 1 | 4 | 64 |
| [app/helpers/common.js](/app/helpers/common.js) | JavaScript | 131 | 11 | 42 | 184 |
| [app/helpers/dashboardMonthFiltersHelper.js](/app/helpers/dashboardMonthFiltersHelper.js) | JavaScript | 158 | 9 | 24 | 191 |
| [app/helpers/deductCredit.js](/app/helpers/deductCredit.js) | JavaScript | 63 | 10 | 12 | 85 |
| [app/helpers/formatCardType.ts](/app/helpers/formatCardType.ts) | TypeScript | 8 | 8 | 4 | 20 |
| [app/helpers/getMicromarketFromCoordinates.ts](/app/helpers/getMicromarketFromCoordinates.ts) | TypeScript | 33 | 5 | 7 | 45 |
| [app/helpers/getUnixDateTime.js](/app/helpers/getUnixDateTime.js) | JavaScript | 71 | 5 | 12 | 88 |
| [app/helpers/nextId.js](/app/helpers/nextId.js) | JavaScript | 51 | 15 | 13 | 79 |
| [app/helpers/shareModal.js](/app/helpers/shareModal.js) | JavaScript | 75 | 3 | 12 | 90 |
| [app/helpers/submitIssue.js](/app/helpers/submitIssue.js) | JavaScript | 36 | 0 | 6 | 42 |
| [app/helpers/submitRequirement.js](/app/helpers/submitRequirement.js) | JavaScript | 63 | 0 | 5 | 68 |
| [app/maintainance.tsx](/app/maintainance.tsx) | TypeScript JSX | 117 | 5 | 12 | 134 |
| [app/modals/ConfirmModal.tsx](/app/modals/ConfirmModal.tsx) | TypeScript JSX | 201 | 1 | 10 | 212 |
| [app/modals/CreditLimitModal.tsx](/app/modals/CreditLimitModal.tsx) | TypeScript JSX | 211 | 1 | 13 | 225 |
| [app/modals/DeleteDraft.tsx](/app/modals/DeleteDraft.tsx) | TypeScript JSX | 222 | 1 | 9 | 232 |
| [app/modals/EnquiryCPModal.tsx](/app/modals/EnquiryCPModal.tsx) | TypeScript JSX | 344 | 4 | 30 | 378 |
| [app/modals/KamModal.tsx](/app/modals/KamModal.tsx) | TypeScript JSX | 242 | 1 | 16 | 259 |
| [app/modals/PaymentUnsuccessfulModal.tsx](/app/modals/PaymentUnsuccessfulModal.tsx) | TypeScript JSX | 215 | 9 | 20 | 244 |
| [app/modals/PremiumModal.tsx](/app/modals/PremiumModal.tsx) | TypeScript JSX | 228 | 5 | 22 | 255 |
| [app/modals/ProfileModal.tsx](/app/modals/ProfileModal.tsx) | TypeScript JSX | 224 | 11 | 16 | 251 |
| [app/modals/SaveAsDraft.tsx](/app/modals/SaveAsDraft.tsx) | TypeScript JSX | 242 | 0 | 10 | 252 |
| [app/modals/ShareModal.tsx](/app/modals/ShareModal.tsx) | TypeScript JSX | 221 | 0 | 16 | 237 |
| [app/not-found.tsx](/app/not-found.tsx) | TypeScript JSX | 30 | 0 | 4 | 34 |
| [app/services/SessionTracker.ts](/app/services/SessionTracker.ts) | TypeScript | 114 | 4 | 19 | 137 |
| [app/types.ts](/app/types.ts) | TypeScript | 619 | 43 | 88 | 750 |
| [assets/icons/CreditCoin.svg](/assets/icons/CreditCoin.svg) | XML | 10 | 0 | 1 | 11 |
| [assets/icons/InAppNotifications/CTA/WhatsAppIcon.tsx](/assets/icons/InAppNotifications/CTA/WhatsAppIcon.tsx) | TypeScript JSX | 42 | 0 | 4 | 46 |
| [assets/icons/InAppNotifications/Checkmark.tsx](/assets/icons/InAppNotifications/Checkmark.tsx) | TypeScript JSX | 24 | 0 | 3 | 27 |
| [assets/icons/InAppNotifications/DoubleCheck.tsx](/assets/icons/InAppNotifications/DoubleCheck.tsx) | TypeScript JSX | 18 | 7 | 4 | 29 |
| [assets/icons/InAppNotifications/Filter.tsx](/assets/icons/InAppNotifications/Filter.tsx) | TypeScript JSX | 25 | 0 | 3 | 28 |
| [assets/icons/InAppNotifications/Settings.tsx](/assets/icons/InAppNotifications/Settings.tsx) | TypeScript JSX | 32 | 0 | 4 | 36 |
| [assets/icons/InAppNotifications/noNotifications.svg](/assets/icons/InAppNotifications/noNotifications.svg) | XML | 28 | 0 | 1 | 29 |
| [assets/icons/Notification/5\_dayEnd.svg](/assets/icons/Notification/5_dayEnd.svg) | XML | 6 | 0 | 1 | 7 |
| [assets/icons/Notification/Archieve.svg](/assets/icons/Notification/Archieve.svg) | XML | 4 | 0 | 1 | 5 |
| [assets/icons/Notification/MarkAsReadInDark.svg](/assets/icons/Notification/MarkAsReadInDark.svg) | XML | 3 | 0 | 1 | 4 |
| [assets/icons/Notification/MarkasRead.svg](/assets/icons/Notification/MarkasRead.svg) | XML | 3 | 0 | 1 | 4 |
| [assets/icons/Notification/lowCredits.svg](/assets/icons/Notification/lowCredits.svg) | XML | 5 | 0 | 1 | 6 |
| [assets/icons/Notification/markAsUnread.svg](/assets/icons/Notification/markAsUnread.svg) | XML | 3 | 0 | 1 | 4 |
| [assets/icons/Notification/rightIcon.svg](/assets/icons/Notification/rightIcon.svg) | XML | 3 | 0 | 0 | 3 |
| [assets/icons/Notification/toStart.svg](/assets/icons/Notification/toStart.svg) | XML | 8 | 0 | 1 | 9 |
| [assets/icons/Notification/trailEnd.svg](/assets/icons/Notification/trailEnd.svg) | XML | 5 | 0 | 1 | 6 |
| [assets/icons/Whatsapp.svg](/assets/icons/Whatsapp.svg) | XML | 15 | 0 | 1 | 16 |
| [assets/icons/apartment.svg](/assets/icons/apartment.svg) | XML | 50 | 0 | 1 | 51 |
| [assets/icons/arrow-2.svg](/assets/icons/arrow-2.svg) | XML | 6 | 0 | 1 | 7 |
| [assets/icons/arrowRightt.svg](/assets/icons/arrowRightt.svg) | XML | 6 | 0 | 1 | 7 |
| [assets/icons/billing/contactSupport.svg](/assets/icons/billing/contactSupport.svg) | XML | 3 | 0 | 1 | 4 |
| [assets/icons/billing/downloadPDF.svg](/assets/icons/billing/downloadPDF.svg) | XML | 6 | 0 | 1 | 7 |
| [assets/icons/billing/emailInvoice.svg](/assets/icons/billing/emailInvoice.svg) | XML | 4 | 0 | 1 | 5 |
| [assets/icons/billing/master-card-icon1.svg](/assets/icons/billing/master-card-icon1.svg) | XML | 11 | 0 | 1 | 12 |
| [assets/icons/billing/retryPayment.svg](/assets/icons/billing/retryPayment.svg) | XML | 4 | 0 | 1 | 5 |
| [assets/icons/close.svg](/assets/icons/close.svg) | XML | 4 | 0 | 1 | 5 |
| [assets/icons/commercialBuilding.svg](/assets/icons/commercialBuilding.svg) | XML | 15 | 0 | 1 | 16 |
| [assets/icons/copyenq.svg](/assets/icons/copyenq.svg) | XML | 4 | 0 | 1 | 5 |
| [assets/icons/flag.svg](/assets/icons/flag.svg) | XML | 4 | 0 | 1 | 5 |
| [assets/icons/independentBuilding.svg](/assets/icons/independentBuilding.svg) | XML | 17 | 0 | 1 | 18 |
| [assets/icons/lock.svg](/assets/icons/lock.svg) | XML | 5 | 0 | 1 | 6 |
| [assets/icons/login.svg](/assets/icons/login.svg) | XML | 3 | 0 | 1 | 4 |
| [assets/icons/officeSpace.svg](/assets/icons/officeSpace.svg) | XML | 8 | 0 | 1 | 9 |
| [assets/icons/paperPlane.svg](/assets/icons/paperPlane.svg) | XML | 5 | 0 | 1 | 6 |
| [assets/icons/paperPlanePremium.svg](/assets/icons/paperPlanePremium.svg) | XML | 5 | 0 | 1 | 6 |
| [assets/icons/plot.svg](/assets/icons/plot.svg) | XML | 19 | 0 | 1 | 20 |
| [assets/icons/receiptMoney.svg](/assets/icons/receiptMoney.svg) | XML | 5 | 0 | 1 | 6 |
| [assets/icons/retailSpace.svg](/assets/icons/retailSpace.svg) | XML | 9 | 0 | 1 | 10 |
| [assets/icons/rowHouse.svg](/assets/icons/rowHouse.svg) | XML | 11 | 0 | 1 | 12 |
| [assets/icons/svg/AddInventory/Appartments.tsx](/assets/icons/svg/AddInventory/Appartments.tsx) | TypeScript JSX | 75 | 0 | 4 | 79 |
| [assets/icons/svg/AddInventory/DropdownIcon.tsx](/assets/icons/svg/AddInventory/DropdownIcon.tsx) | TypeScript JSX | 35 | 0 | 3 | 38 |
| [assets/icons/svg/AddInventory/IndependentBuilding.tsx](/assets/icons/svg/AddInventory/IndependentBuilding.tsx) | TypeScript JSX | 75 | 0 | 4 | 79 |
| [assets/icons/svg/AddInventory/OfficeSpace.tsx](/assets/icons/svg/AddInventory/OfficeSpace.tsx) | TypeScript JSX | 99 | 0 | 3 | 102 |
| [assets/icons/svg/AddInventory/Plots.tsx](/assets/icons/svg/AddInventory/Plots.tsx) | TypeScript JSX | 90 | 0 | 4 | 94 |
| [assets/icons/svg/AddInventory/RowHouse.tsx](/assets/icons/svg/AddInventory/RowHouse.tsx) | TypeScript JSX | 81 | 0 | 4 | 85 |
| [assets/icons/svg/AddInventory/ShowLessButton.tsx](/assets/icons/svg/AddInventory/ShowLessButton.tsx) | TypeScript JSX | 44 | 0 | 4 | 48 |
| [assets/icons/svg/AddInventory/ShowMoreButton.tsx](/assets/icons/svg/AddInventory/ShowMoreButton.tsx) | TypeScript JSX | 44 | 0 | 3 | 47 |
| [assets/icons/svg/AddInventory/UploadFiles.tsx](/assets/icons/svg/AddInventory/UploadFiles.tsx) | TypeScript JSX | 55 | 0 | 4 | 59 |
| [assets/icons/svg/AddInventory/Villa.tsx](/assets/icons/svg/AddInventory/Villa.tsx) | TypeScript JSX | 77 | 0 | 4 | 81 |
| [assets/icons/svg/AddInventory/Villaments.tsx](/assets/icons/svg/AddInventory/Villaments.tsx) | TypeScript JSX | 75 | 0 | 3 | 78 |
| [assets/icons/svg/CloseIcon.tsx](/assets/icons/svg/CloseIcon.tsx) | TypeScript JSX | 34 | 9 | 5 | 48 |
| [assets/icons/svg/Common/ArrowLeftIcon.tsx](/assets/icons/svg/Common/ArrowLeftIcon.tsx) | TypeScript JSX | 36 | 0 | 4 | 40 |
| [assets/icons/svg/Common/ArrowRightIcon.tsx](/assets/icons/svg/Common/ArrowRightIcon.tsx) | TypeScript JSX | 25 | 0 | 4 | 29 |
| [assets/icons/svg/Common/DoubleRightArrow.tsx](/assets/icons/svg/Common/DoubleRightArrow.tsx) | TypeScript JSX | 39 | 0 | 4 | 43 |
| [assets/icons/svg/Common/LogoutIcon.tsx](/assets/icons/svg/Common/LogoutIcon.tsx) | TypeScript JSX | 42 | 0 | 4 | 46 |
| [assets/icons/svg/Common/PlusIcon.tsx](/assets/icons/svg/Common/PlusIcon.tsx) | TypeScript JSX | 34 | 0 | 4 | 38 |
| [assets/icons/svg/Common/PlusIconWithCircle.tsx](/assets/icons/svg/Common/PlusIconWithCircle.tsx) | TypeScript JSX | 41 | 0 | 4 | 45 |
| [assets/icons/svg/Common/TrashIcon.tsx](/assets/icons/svg/Common/TrashIcon.tsx) | TypeScript JSX | 55 | 0 | 4 | 59 |
| [assets/icons/svg/Dashboard/MyEnquiryIcon.tsx](/assets/icons/svg/Dashboard/MyEnquiryIcon.tsx) | TypeScript JSX | 63 | 0 | 4 | 67 |
| [assets/icons/svg/Dashboard/MyInventoriesIcon.tsx](/assets/icons/svg/Dashboard/MyInventoriesIcon.tsx) | TypeScript JSX | 29 | 0 | 4 | 33 |
| [assets/icons/svg/Dashboard/MyRequirementsIcon.tsx](/assets/icons/svg/Dashboard/MyRequirementsIcon.tsx) | TypeScript JSX | 39 | 0 | 4 | 43 |
| [assets/icons/svg/Footer/ActiveDashboardIcon.tsx](/assets/icons/svg/Footer/ActiveDashboardIcon.tsx) | TypeScript JSX | 82 | 0 | 4 | 86 |
| [assets/icons/svg/Footer/ActiveNotificationsIcon.tsx](/assets/icons/svg/Footer/ActiveNotificationsIcon.tsx) | TypeScript JSX | 50 | 0 | 4 | 54 |
| [assets/icons/svg/Footer/ActivePropertiesIcon.tsx](/assets/icons/svg/Footer/ActivePropertiesIcon.tsx) | TypeScript JSX | 34 | 0 | 4 | 38 |
| [assets/icons/svg/Footer/ActiveRequirementsIcon.tsx](/assets/icons/svg/Footer/ActiveRequirementsIcon.tsx) | TypeScript JSX | 50 | 0 | 4 | 54 |
| [assets/icons/svg/Footer/AddInventoryIcon.tsx](/assets/icons/svg/Footer/AddInventoryIcon.tsx) | TypeScript JSX | 50 | 0 | 4 | 54 |
| [assets/icons/svg/Footer/AddRequirementsIcon.tsx](/assets/icons/svg/Footer/AddRequirementsIcon.tsx) | TypeScript JSX | 73 | 0 | 4 | 77 |
| [assets/icons/svg/Footer/DashboardIcon.tsx](/assets/icons/svg/Footer/DashboardIcon.tsx) | TypeScript JSX | 52 | 0 | 4 | 56 |
| [assets/icons/svg/Footer/NotificationIcon.tsx](/assets/icons/svg/Footer/NotificationIcon.tsx) | TypeScript JSX | 41 | 0 | 4 | 45 |
| [assets/icons/svg/Footer/PropertiesIcon.tsx](/assets/icons/svg/Footer/PropertiesIcon.tsx) | TypeScript JSX | 36 | 0 | 4 | 40 |
| [assets/icons/svg/Footer/RequirementsIcon.tsx](/assets/icons/svg/Footer/RequirementsIcon.tsx) | TypeScript JSX | 48 | 0 | 4 | 52 |
| [assets/icons/svg/HamburgerMenuIcon.tsx](/assets/icons/svg/HamburgerMenuIcon.tsx) | TypeScript JSX | 48 | 0 | 4 | 52 |
| [assets/icons/svg/HandoverIcon.tsx](/assets/icons/svg/HandoverIcon.tsx) | TypeScript JSX | 51 | 0 | 4 | 55 |
| [assets/icons/svg/Header/UserIcon.tsx](/assets/icons/svg/Header/UserIcon.tsx) | TypeScript JSX | 26 | 0 | 4 | 30 |
| [assets/icons/svg/KamModalIcon.tsx](/assets/icons/svg/KamModalIcon.tsx) | TypeScript JSX | 42 | 10 | 5 | 57 |
| [assets/icons/svg/ProfilePage/KamIcon.tsx](/assets/icons/svg/ProfilePage/KamIcon.tsx) | TypeScript JSX | 45 | 0 | 4 | 49 |
| [assets/icons/svg/ProfilePage/PaymentRecordsIcon.tsx](/assets/icons/svg/ProfilePage/PaymentRecordsIcon.tsx) | TypeScript JSX | 43 | 0 | 4 | 47 |
| [assets/icons/svg/ProfilePage/PremiumIcon.tsx](/assets/icons/svg/ProfilePage/PremiumIcon.tsx) | TypeScript JSX | 43 | 0 | 4 | 47 |
| [assets/icons/svg/ProfilePage/SupportIcon.tsx](/assets/icons/svg/ProfilePage/SupportIcon.tsx) | TypeScript JSX | 42 | 0 | 4 | 46 |
| [assets/icons/svg/PropertiesPage/DriveIcon.tsx](/assets/icons/svg/PropertiesPage/DriveIcon.tsx) | TypeScript JSX | 43 | 0 | 4 | 47 |
| [assets/icons/svg/PropertiesPage/FilterIcon.tsx](/assets/icons/svg/PropertiesPage/FilterIcon.tsx) | TypeScript JSX | 57 | 10 | 5 | 72 |
| [assets/icons/svg/PropertiesPage/SHareIconPropertyDetailsModal.tsx](/assets/icons/svg/PropertiesPage/SHareIconPropertyDetailsModal.tsx) | TypeScript JSX | 91 | 0 | 4 | 95 |
| [assets/icons/svg/PropertiesPage/SearchIcon.tsx](/assets/icons/svg/PropertiesPage/SearchIcon.tsx) | TypeScript JSX | 44 | 0 | 4 | 48 |
| [assets/icons/svg/PropertiesPage/ShareIcon.tsx](/assets/icons/svg/PropertiesPage/ShareIcon.tsx) | TypeScript JSX | 25 | 0 | 4 | 29 |
| [assets/icons/svg/PropertyFolder/location.svg](/assets/icons/svg/PropertyFolder/location.svg) | XML | 4 | 0 | 1 | 5 |
| [assets/icons/svg/PropertyFolder/shareButton.svg](/assets/icons/svg/PropertyFolder/shareButton.svg) | XML | 3 | 0 | 1 | 4 |
| [assets/icons/svg/Sidebar/BillingIcon.tsx](/assets/icons/svg/Sidebar/BillingIcon.tsx) | TypeScript JSX | 22 | 0 | 4 | 26 |
| [assets/icons/svg/Sidebar/CoinIcon.tsx](/assets/icons/svg/Sidebar/CoinIcon.tsx) | TypeScript JSX | 44 | 0 | 4 | 48 |
| [assets/icons/svg/Sidebar/DashboardIcon.tsx](/assets/icons/svg/Sidebar/DashboardIcon.tsx) | TypeScript JSX | 55 | 0 | 4 | 59 |
| [assets/icons/svg/Sidebar/PropertyIcon.tsx](/assets/icons/svg/Sidebar/PropertyIcon.tsx) | TypeScript JSX | 71 | 0 | 17 | 88 |
| [assets/icons/svg/Sidebar/RequirementsIcon.tsx](/assets/icons/svg/Sidebar/RequirementsIcon.tsx) | TypeScript JSX | 36 | 0 | 4 | 40 |
| [assets/icons/tnc.svg](/assets/icons/tnc.svg) | XML | 5 | 0 | 1 | 6 |
| [assets/icons/user-tick.svg](/assets/icons/user-tick.svg) | XML | 6 | 0 | 1 | 7 |
| [assets/icons/villa.svg](/assets/icons/villa.svg) | XML | 5 | 0 | 1 | 6 |
| [assets/icons/villament.svg](/assets/icons/villament.svg) | XML | 10 | 0 | 1 | 11 |
| [assets/icons/whatsAppgreen.svg 14-54-26-826.svg](/assets/icons/whatsAppgreen.svg%2014-54-26-826.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/merged.json](/assets/merged.json) | JSON | 97,941 | 0 | 0 | 97,941 |
| [babel.config.js](/babel.config.js) | JavaScript | 10 | 7 | 1 | 18 |
| [billing\_update\_plan.md](/billing_update_plan.md) | Markdown | 27 | 0 | 11 | 38 |
| [components/AddPopup.tsx](/components/AddPopup.tsx) | TypeScript JSX | 214 | 0 | 8 | 222 |
| [components/AnimatedTooltip.tsx](/components/AnimatedTooltip.tsx) | TypeScript JSX | 158 | 2 | 14 | 174 |
| [components/Collapsible.tsx](/components/Collapsible.tsx) | TypeScript JSX | 46 | 0 | 6 | 52 |
| [components/ExternalLink.tsx](/components/ExternalLink.tsx) | TypeScript JSX | 20 | 2 | 3 | 25 |
| [components/FooterNavigation.tsx](/components/FooterNavigation.tsx) | TypeScript JSX | 360 | 2 | 28 | 390 |
| [components/HamburgerMenu.tsx](/components/HamburgerMenu.tsx) | TypeScript JSX | 514 | 5 | 29 | 548 |
| [components/HamburgerMenuButton.tsx](/components/HamburgerMenuButton.tsx) | TypeScript JSX | 82 | 1 | 6 | 89 |
| [components/HapticTab.tsx](/components/HapticTab.tsx) | TypeScript JSX | 16 | 1 | 2 | 19 |
| [components/HelloWave.tsx](/components/HelloWave.tsx) | TypeScript JSX | 37 | 0 | 7 | 44 |
| [components/KamModalButton.tsx](/components/KamModalButton.tsx) | TypeScript JSX | 104 | 0 | 7 | 111 |
| [components/ParallaxScrollView.tsx](/components/ParallaxScrollView.tsx) | TypeScript JSX | 82 | 0 | 7 | 89 |
| [components/ThemedText.tsx](/components/ThemedText.tsx) | TypeScript JSX | 55 | 0 | 6 | 61 |
| [components/ThemedView.tsx](/components/ThemedView.tsx) | TypeScript JSX | 18 | 0 | 5 | 23 |
| [components/\_\_tests\_\_/ThemedText-test.tsx](/components/__tests__/ThemedText-test.tsx) | TypeScript JSX | 9 | 0 | 4 | 13 |
| [components/ui/IconSymbol.ios.tsx](/components/ui/IconSymbol.ios.tsx) | TypeScript JSX | 31 | 0 | 2 | 33 |
| [components/ui/IconSymbol.tsx](/components/ui/IconSymbol.tsx) | TypeScript JSX | 37 | 9 | 5 | 51 |
| [components/ui/PrimaryButton.tsx](/components/ui/PrimaryButton.tsx) | TypeScript JSX | 105 | 3 | 6 | 114 |
| [components/ui/TabBarBackground.ios.tsx](/components/ui/TabBarBackground.ios.tsx) | TypeScript JSX | 18 | 2 | 3 | 23 |
| [components/ui/TabBarBackground.tsx](/components/ui/TabBarBackground.tsx) | TypeScript JSX | 4 | 1 | 2 | 7 |
| [constants/Colors.ts](/constants/Colors.ts) | TypeScript | 20 | 4 | 3 | 27 |
| [eas.json](/eas.json) | JSON | 21 | 0 | 1 | 22 |
| [global.css](/global.css) | PostCSS | 3 | 0 | 1 | 4 |
| [google-services.json](/google-services.json) | JSON | 63 | 0 | 0 | 63 |
| [hooks/useBackToSaveDraft.ts](/hooks/useBackToSaveDraft.ts) | TypeScript | 20 | 9 | 4 | 33 |
| [hooks/useColorScheme.ts](/hooks/useColorScheme.ts) | TypeScript | 1 | 0 | 1 | 2 |
| [hooks/useColorScheme.web.ts](/hooks/useColorScheme.web.ts) | TypeScript | 13 | 3 | 6 | 22 |
| [hooks/useCustomBackBehavior.ts](/hooks/useCustomBackBehavior.ts) | TypeScript | 26 | 2 | 5 | 33 |
| [hooks/useDoubleBackPressExit.ts](/hooks/useDoubleBackPressExit.ts) | TypeScript | 40 | 12 | 9 | 61 |
| [hooks/useThemeColor.ts](/hooks/useThemeColor.ts) | TypeScript | 14 | 4 | 4 | 22 |
| [metro.config.js](/metro.config.js) | JavaScript | 14 | 1 | 5 | 20 |
| [package-lock.json](/package-lock.json) | JSON | 24,977 | 0 | 1 | 24,978 |
| [package.json](/package.json) | JSON | 119 | 0 | 1 | 120 |
| [patches/react-native+0.76.9.patch](/patches/react-native+0.76.9.patch) | Diff | 241 | 20 | 1 | 262 |
| [providers/ReduxProvider.tsx](/providers/ReduxProvider.tsx) | TypeScript JSX | 17 | 0 | 2 | 19 |
| [react-native-dotenv.d.ts](/react-native-dotenv.d.ts) | TypeScript | 0 | 11 | 1 | 12 |
| [react-native.config.js](/react-native.config.js) | JavaScript | 10 | 0 | 0 | 10 |
| [scripts/reset-project.js](/scripts/reset-project.js) | JavaScript | 92 | 10 | 14 | 116 |
| [store/slices/agentSlice.ts](/store/slices/agentSlice.ts) | TypeScript | 325 | 16 | 38 | 379 |
| [store/slices/appSlice.ts](/store/slices/appSlice.ts) | TypeScript | 18 | 0 | 6 | 24 |
| [store/slices/authSlice.ts](/store/slices/authSlice.ts) | TypeScript | 109 | 1 | 14 | 124 |
| [store/slices/kamSlice.ts](/store/slices/kamSlice.ts) | TypeScript | 94 | 5 | 10 | 109 |
| [store/slices/listenerSlice.ts](/store/slices/listenerSlice.ts) | TypeScript | 66 | 1 | 6 | 73 |
| [store/slices/paymentSlics.ts](/store/slices/paymentSlics.ts) | TypeScript | 0 | 125 | 20 | 145 |
| [store/slices/propertySlice.ts](/store/slices/propertySlice.ts) | TypeScript | 87 | 7 | 10 | 104 |
| [store/slices/requirementSlice.ts](/store/slices/requirementSlice.ts) | TypeScript | 93 | 7 | 9 | 109 |
| [store/store.ts](/store/store.ts) | TypeScript | 35 | 4 | 10 | 49 |
| [tailwind.config.js](/tailwind.config.js) | JavaScript | 7 | 1 | 1 | 9 |
| [tsconfig.json](/tsconfig.json) | JSON with Comments | 16 | 0 | 1 | 17 |
| [types/images.d.ts](/types/images.d.ts) | TypeScript | 6 | 0 | 1 | 7 |
| [utils/toastUtils.ts](/utils/toastUtils.ts) | TypeScript | 92 | 1 | 11 | 104 |
| [utils/userUtils.ts](/utils/userUtils.ts) | TypeScript | 11 | 0 | 1 | 12 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)
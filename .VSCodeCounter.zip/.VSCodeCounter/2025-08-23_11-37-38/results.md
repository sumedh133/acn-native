# Summary

Date : 2025-08-23 11:37:38

Directory c:\\IQOL\\acn-native

Total : 304 files,  165326 codes, 1756 comments, 3543 blanks, all 170625 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 6 | 123,198 | 0 | 4 | 123,202 |
| TypeScript JSX | 204 | 37,034 | 1,367 | 2,912 | 41,313 |
| TypeScript | 28 | 2,649 | 297 | 346 | 3,292 |
| XML | 46 | 1,062 | 0 | 39 | 1,101 |
| JavaScript | 14 | 974 | 72 | 147 | 1,193 |
| Diff | 1 | 241 | 20 | 1 | 262 |
| Markdown | 3 | 149 | 0 | 92 | 241 |
| JSON with Comments | 1 | 16 | 0 | 1 | 17 |
| PostCSS | 1 | 3 | 0 | 1 | 4 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 304 | 165,326 | 1,756 | 3,543 | 170,625 |
| . (Files) | 14 | 25,376 | 20 | 46 | 25,442 |
| .idea | 5 | 731 | 0 | 0 | 731 |
| .idea (Files) | 4 | 28 | 0 | 0 | 28 |
| .idea\\caches | 1 | 703 | 0 | 0 | 703 |
| app | 147 | 34,945 | 1,441 | 2,893 | 39,279 |
| app (Files) | 7 | 1,671 | 104 | 200 | 1,975 |
| app\\(pages) | 8 | 2,800 | 149 | 210 | 3,159 |
| app\\(tabs) | 11 | 5,018 | 226 | 453 | 5,697 |
| app\\components | 95 | 21,995 | 855 | 1,700 | 24,550 |
| app\\components (Files) | 14 | 3,465 | 128 | 273 | 3,866 |
| app\\components\\Auth | 6 | 1,397 | 67 | 110 | 1,574 |
| app\\components\\Billing | 2 | 2,052 | 88 | 181 | 2,321 |
| app\\components\\Button | 2 | 207 | 0 | 18 | 225 |
| app\\components\\Enquiries | 2 | 427 | 6 | 37 | 470 |
| app\\components\\Listing | 23 | 4,450 | 137 | 229 | 4,816 |
| app\\components\\Listing (Files) | 13 | 2,256 | 87 | 168 | 2,511 |
| app\\components\\Listing\\ComponentObjects | 7 | 1,753 | 22 | 9 | 1,784 |
| app\\components\\Listing\\document | 3 | 441 | 28 | 52 | 521 |
| app\\components\\Notification | 10 | 2,137 | 104 | 236 | 2,477 |
| app\\components\\Onboarding | 12 | 822 | 7 | 104 | 933 |
| app\\components\\Onboarding (Files) | 1 | 3 | 0 | 0 | 3 |
| app\\components\\Onboarding\\components | 7 | 443 | 6 | 53 | 502 |
| app\\components\\Onboarding\\screens | 4 | 376 | 1 | 51 | 428 |
| app\\components\\Payments | 2 | 899 | 14 | 27 | 940 |
| app\\components\\ProfilePage | 4 | 648 | 23 | 36 | 707 |
| app\\components\\dashboard | 7 | 1,734 | 56 | 127 | 1,917 |
| app\\components\\property | 4 | 2,366 | 129 | 177 | 2,672 |
| app\\components\\requirement | 7 | 1,391 | 96 | 145 | 1,632 |
| app\\config | 1 | 16 | 3 | 4 | 23 |
| app\\constants | 2 | 40 | 0 | 4 | 44 |
| app\\helpers | 12 | 941 | 67 | 141 | 1,149 |
| app\\modals | 10 | 2,350 | 33 | 162 | 2,545 |
| app\\services | 1 | 114 | 4 | 19 | 137 |
| assets | 97 | 100,944 | 36 | 269 | 101,249 |
| assets (Files) | 1 | 97,941 | 0 | 0 | 97,941 |
| assets\\icons | 96 | 3,003 | 36 | 269 | 3,308 |
| assets\\icons (Files) | 24 | 228 | 0 | 23 | 251 |
| assets\\icons\\InAppNotifications | 6 | 169 | 7 | 19 | 195 |
| assets\\icons\\InAppNotifications (Files) | 5 | 127 | 7 | 15 | 149 |
| assets\\icons\\InAppNotifications\\CTA | 1 | 42 | 0 | 4 | 46 |
| assets\\icons\\Notification | 9 | 40 | 0 | 8 | 48 |
| assets\\icons\\billing | 5 | 28 | 0 | 5 | 33 |
| assets\\icons\\svg | 52 | 2,538 | 29 | 214 | 2,781 |
| assets\\icons\\svg (Files) | 4 | 175 | 19 | 18 | 212 |
| assets\\icons\\svg\\AddInventory | 11 | 750 | 0 | 40 | 790 |
| assets\\icons\\svg\\Common | 7 | 272 | 0 | 28 | 300 |
| assets\\icons\\svg\\Dashboard | 3 | 131 | 0 | 12 | 143 |
| assets\\icons\\svg\\Footer | 10 | 516 | 0 | 40 | 556 |
| assets\\icons\\svg\\Header | 1 | 26 | 0 | 4 | 30 |
| assets\\icons\\svg\\ProfilePage | 4 | 173 | 0 | 16 | 189 |
| assets\\icons\\svg\\PropertiesPage | 5 | 260 | 10 | 21 | 291 |
| assets\\icons\\svg\\PropertyFolder | 2 | 7 | 0 | 2 | 9 |
| assets\\icons\\svg\\Sidebar | 5 | 228 | 0 | 33 | 261 |
| components | 19 | 1,910 | 28 | 150 | 2,088 |
| components (Files) | 13 | 1,706 | 13 | 128 | 1,847 |
| components\\__tests__ | 1 | 9 | 0 | 4 | 13 |
| components\\ui | 5 | 195 | 15 | 18 | 228 |
| constants | 1 | 20 | 4 | 3 | 27 |
| hooks | 6 | 114 | 30 | 29 | 173 |
| patches | 1 | 241 | 20 | 1 | 262 |
| providers | 1 | 17 | 0 | 2 | 19 |
| scripts | 1 | 92 | 10 | 14 | 116 |
| store | 9 | 827 | 166 | 123 | 1,116 |
| store (Files) | 1 | 35 | 4 | 10 | 49 |
| store\\slices | 8 | 792 | 162 | 113 | 1,067 |
| types | 1 | 6 | 0 | 1 | 7 |
| utils | 2 | 103 | 1 | 12 | 116 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)